def parallelogram_area(base, height):
    return base * height

# Example usage
base = 5
height = 6
area = parallelogram_area(base, height)

print(f"Length of base: {base}")
print(f"Height of parallelogram: {height}")
print(f"Expected Output: {area:.1f}")